package com.example.taskology

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
