plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace 'com.example.taskology' // uyğun paket adınla dəyiş
    compileSdkVersion 34

    defaultConfig {
        applicationId "com.example.taskology"
        minSdkVersion 23  // flutter_secure_storage və EncryptedSharedPreferences üçün tövsiyə olunur. :contentReference[oaicite:3]{index=3}
        targetSdkVersion 34
        versionCode 1
        versionName "0.1.0"
    }

    compileOptions {
    sourceCompatibility JavaVersion.VERSION_17
    targetCompatibility JavaVersion.VERSION_17
}

    kotlinOptions {
        jvmTarget = "17"
    }
}

flutter {
    source = "../.."
}
