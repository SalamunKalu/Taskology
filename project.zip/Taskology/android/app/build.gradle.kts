// DÜZƏLİŞ: Lazım olan Java siniflərini import edirik (faylın ən başında olmalıdır)
import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    // DÜZƏLİŞ: key.properties oxuma məntiqini android blokunun içinə köçürürük
    val keyProperties = Properties()
    val keyPropertiesFile = rootProject.file("key.properties")
    if (keyPropertiesFile.exists()) {
        // .use bloku faylı avtomatik bağlayır, daha təhlükəsizdir
        FileInputStream(keyPropertiesFile).use { input ->
            keyProperties.load(input)
        }
    }

    // KRİTİK DÜZƏLİŞ: namespace və SDK versiyaları
    namespace = "com.menimtetbiqim.taskology" 
    compileSdk = 36

    defaultConfig {
        applicationId = "com.menimtetbiqim.taskology"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    signingConfigs {
        create("release") {
            keyAlias = keyProperties["keyAlias"] as String?
            keyPassword = keyProperties["keyPassword"] as String?
            storeFile = if (keyProperties["storeFile"] != null) file(keyProperties["storeFile"] as String) else null
            storePassword = keyProperties["storePassword"] as String?
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

flutter {
    source = "../.."
}