import 'dart:convert';
import 'dart:math';

/// 64-byte-lik random key yaradır
String generateDbKey() {
  final random = Random.secure();
  final values = List<int>.generate(64, (_) => random.nextInt(256));
  return base64UrlEncode(values);
}
