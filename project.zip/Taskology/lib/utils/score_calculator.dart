import '../models/task.dart';

class ScoreCalculator {
  static int calculateTaskScore(Task task) {
    switch (task.priority) {
      case 3: // High
        if (task.completed) return 10;
        if (task.postponed) return -5;
        return -10;
      case 2: // Medium
        if (task.completed) return 7;
        if (task.postponed) return -4;
        return -7;
      case 1: // Low
        if (task.completed) return 5;
        if (task.postponed) return -3;
        return -5;
      default:
        return 0;
    }
  }
}
