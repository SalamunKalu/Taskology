import 'package:flutter/material.dart';
import '../db/app_database.dart';
import '../models/task.dart';
import '../utils/score_calculator.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Task> tasks = [];

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    final list = await AppDatabase.getTasks();
    setState(() {
      tasks = list;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Taskology')),
      body: ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          final task = tasks[index];
          final score = ScoreCalculator.calculateTaskScore(task);
          return ListTile(
            title: Text(task.title),
            subtitle: Text('Score: $score'),
            trailing: Checkbox(
              value: task.completed,
              onChanged: (val) async {
                task.completed = val ?? false;
                await AppDatabase.updateTask(task);
                _loadTasks();
              },
            ),
          );
        },
      ),
    );
  }
}
