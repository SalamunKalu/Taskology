// ========================================================
// Taskology - The ABSOLUTELY Final, Clean, All-in-One main.dart App
// ========================================================

import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p; // Imported with a prefix 'p' to avoid name collision
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

// ========================================================
// MAIN FUNCTION
// ========================================================
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.getDatabase();
  runApp(const MyApp());
}

// ========================================================
// APP WIDGET (Root of the application)
// ========================================================
class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.system;

  void toggleTheme(bool isDarkMode) {
    setState(() {
      _themeMode = isDarkMode ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Taskology',
      theme: ThemeData.light(useMaterial3: true),
      darkTheme: ThemeData.dark(useMaterial3: true),
      themeMode: _themeMode,
      debugShowCheckedModeBanner: false,
      home: HomePage(onToggleTheme: toggleTheme),
    );
  }
}

// ========================================================
// TASK MODEL (Functionality Restored)
// ========================================================
class Task {
  final String id;
  String title;
  String category;
  int priority;
  int totalMinutes;
  int totalDays;
  List<String> weekdays;
  final DateTime createdAt;
  bool completed;
  bool postponed;

  Task({
    required this.id,
    required this.title,
    required this.category,
    required this.priority,
    required this.totalMinutes,
    required this.totalDays,
    required this.weekdays,
    required this.createdAt,
    this.completed = false,
    this.postponed = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'category': category,
      'priority': priority,
      'totalMinutes': totalMinutes,
      'totalDays': totalDays,
      'weekdays': weekdays.join(','),
      'createdAt': createdAt.toIso8601String(),
      'completed': completed ? 1 : 0,
      'postponed': postponed ? 1 : 0,
    };
  }

  factory Task.fromMap(Map<String, dynamic> map) {
    return Task(
      id: map['id'],
      title: map['title'],
      category: map['category'],
      priority: map['priority'],
      totalMinutes: map['totalMinutes'] ?? 0,
      totalDays: map['totalDays'] ?? 0,
      weekdays: (map['weekdays'] as String?)?.split(',') ?? [],
      createdAt: DateTime.parse(map['createdAt']),
      completed: map['completed'] == 1,
      postponed: map['postponed'] == 1,
    );
  }
}

// ========================================================
// DATABASE SERVICE (Encrypted)
// ========================================================
class AppDatabase {
  static Database? _db;
  static const String _dbName = 'taskology.db';

  static Future<Database> getDatabase() async {
    if (_db != null) return _db!;

    const storage = FlutterSecureStorage();
    String? key = await storage.read(
      key: 'db_key',
      aOptions: const AndroidOptions(encryptedSharedPreferences: true),
    );
    if (key == null) {
      final random = Random.secure();
      final values = List<int>.generate(64, (_) => random.nextInt(256));
      key = base64UrlEncode(values);
      await storage.write(
        key: 'db_key',
        value: key,
        aOptions: const AndroidOptions(encryptedSharedPreferences: true),
      );
    }

    final path = p.join(await getDatabasesPath(), _dbName);
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE tasks(
            id TEXT PRIMARY KEY,
            title TEXT,
            category TEXT,
            priority INTEGER,
            totalMinutes INTEGER,
            totalDays INTEGER,
            weekdays TEXT,
            createdAt TEXT,
            completed INTEGER,
            postponed INTEGER
          )
        ''');
      },
    );
    return _db!;
  }

  static Future<void> insertTask(Task task) async {
    final db = await getDatabase();
    await db.insert('tasks', task.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<List<Task>> getTasks() async {
    final db = await getDatabase();
    final maps = await db.query('tasks', orderBy: 'createdAt DESC');
    return maps.map((e) => Task.fromMap(e)).toList();
  }

  static Future<void> updateTask(Task task) async {
    final db = await getDatabase();
    await db.update('tasks', task.toMap(), where: 'id = ?', whereArgs: [task.id]);
  }

  static Future<void> deleteTask(String id) async {
    final db = await getDatabase();
    await db.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }
}

// ========================================================
// BACKUP SERVICE (JSON Export/Import)
// ========================================================
class BackupService {
  static Future<File> exportDbToJson() async {
    final db = await AppDatabase.getDatabase();
    final tasks = await db.query('tasks');
    final jsonStr = jsonEncode(tasks);
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'taskology_backup.json'));
    return file.writeAsString(jsonStr);
  }

  static Future<void> importDbFromJson(File file) async {
    final content = await file.readAsString();
    final List<dynamic> data = jsonDecode(content);
    for (var map in data) {
      final taskMap = Map<String, dynamic>.from(map);
      await AppDatabase.insertTask(Task.fromMap(taskMap));
    }
  }
}

// ========================================================
// SCORE & STREAK CALCULATOR
// ========================================================
class ScoreCalculator {
  static int calculateTaskScore(Task task) {
    if (task.completed) {
      switch (task.priority) {
        case 3: return 10;
        case 2: return 7;
        case 1: return 5;
      }
    }
    if (task.postponed) {
      switch (task.priority) {
        case 3: return -5;
        case 2: return -4;
        case 1: return -3;
      }
    }
    switch (task.priority) {
      case 3: return -10;
      case 2: return -7;
      case 1: return -5;
    }
    return 0;
  }

  static int calculateStreakBonus(List<Task> allCompletedTasks) {
    if (allCompletedTasks.length < 5) return 0;
    allCompletedTasks.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    int consecutiveDays = 0;
    DateTime? lastDay;
    for (var task in allCompletedTasks) {
      final taskDay = DateTime(task.createdAt.year, task.createdAt.month, task.createdAt.day);
      if (lastDay == null) {
        consecutiveDays = 1;
      } else {
        if (taskDay.difference(lastDay).inDays == 1) {
          consecutiveDays++;
        } else if (taskDay.difference(lastDay).inDays > 1) {
          consecutiveDays = 1;
        }
      }
      lastDay = taskDay;
    }
    return (consecutiveDays ~/ 5) * 10;
  }
}

// ========================================================
// HOME PAGE UI
// ========================================================
class HomePage extends StatefulWidget {
  final Function(bool) onToggleTheme;
  const HomePage({super.key, required this.onToggleTheme});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  List<Task> tasks = [];
  late TabController _tabController;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    setState(() => _isLoading = true);
    final taskList = await AppDatabase.getTasks();
    setState(() {
      tasks = taskList;
      _isLoading = false;
    });
  }

  Future<void> _showTaskDialog({Task? task}) async {
    final isEditing = task != null;
    final titleController = TextEditingController(text: task?.title ?? '');
    final minutesController = TextEditingController(text: task?.totalMinutes.toString() ?? '60');
    final daysController = TextEditingController(text: task?.totalDays.toString() ?? '1');
    String category = task?.category ?? 'General';
    int priority = task?.priority ?? 2;
    Set<String> selectedWeekdays = task?.weekdays.toSet() ?? {};

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (statefulBuilderContext, setDialogState) {
            return AlertDialog(
              title: Text(isEditing ? 'Edit Task' : 'Add Task'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Title')),
                    TextField(controller: minutesController, decoration: const InputDecoration(labelText: 'Minutes per session'), keyboardType: TextInputType.number),
                    TextField(controller: daysController, decoration: const InputDecoration(labelText: 'Total days'), keyboardType: TextInputType.number),
                    const SizedBox(height: 8),
                    // CORRECTED: Using InputDecorator + DropdownButton to avoid deprecation warning
                    InputDecorator(
                      decoration: const InputDecoration(
                        labelText: 'Category',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: category,
                          isExpanded: true,
                          items: ['Work', 'Personal', 'Health', 'General', 'Study'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                          onChanged: (val) => setDialogState(() => category = val ?? 'General'),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    // CORRECTED: Using InputDecorator + DropdownButton to avoid deprecation warning
                    InputDecorator(
                      decoration: const InputDecoration(
                        labelText: 'Priority',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<int>(
                          value: priority,
                          isExpanded: true,
                          items: const [
                            DropdownMenuItem(value: 3, child: Text('High Priority')),
                            DropdownMenuItem(value: 2, child: Text('Medium Priority')),
                            DropdownMenuItem(value: 1, child: Text('Low Priority')),
                          ],
                          onChanged: (val) => setDialogState(() => priority = val ?? 2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 4,
                      children: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) {
                        return FilterChip(
                          label: Text(day),
                          selected: selectedWeekdays.contains(day),
                          onSelected: (selected) {
                            setDialogState(() {
                              if (selected) {
                                selectedWeekdays.add(day);
                              } else {
                                selectedWeekdays.remove(day);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
                ElevatedButton(
                  onPressed: () async {
                    if (titleController.text.isEmpty) return;

                    if (isEditing) {
                      task.title = titleController.text;
                      task.category = category;
                      task.priority = priority;
                      task.totalMinutes = int.tryParse(minutesController.text) ?? 60;
                      task.totalDays = int.tryParse(daysController.text) ?? 1;
                      task.weekdays = selectedWeekdays.toList();
                      await AppDatabase.updateTask(task);
                    } else {
                      final newTask = Task(
                        id: DateTime.now().millisecondsSinceEpoch.toString(),
                        createdAt: DateTime.now(),
                        title: titleController.text,
                        category: category,
                        priority: priority,
                        totalMinutes: int.tryParse(minutesController.text) ?? 60,
                        totalDays: int.tryParse(daysController.text) ?? 1,
                        weekdays: selectedWeekdays.toList(),
                      );
                      await AppDatabase.insertTask(newTask);
                    }
                    Navigator.pop(dialogContext);
                    _loadTasks();
                  },
                  child: Text(isEditing ? 'Save' : 'Add'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Taskology'),
        actions: [
          IconButton(
            icon: Icon(isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => widget.onToggleTheme(!isDarkMode),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.list_alt), text: 'Tasks'),
            Tab(icon: Icon(Icons.bar_chart), text: 'Stats'),
            Tab(icon: Icon(Icons.backup), text: 'Backup'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showTaskDialog(),
        child: const Icon(Icons.add),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                _buildTasksTab(),
                _buildStatsTab(),
                _buildBackupTab(),
              ],
            ),
    );
  }

  Widget _buildTasksTab() {
    if (tasks.isEmpty) {
      return const Center(child: Text("No tasks yet. Add one!"));
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 80),
      itemCount: tasks.length,
      itemBuilder: (ctx, index) {
        final task = tasks[index];
        final score = ScoreCalculator.calculateTaskScore(task);
        final priorityColor = task.priority == 3 ? Colors.red.shade300 : task.priority == 2 ? Colors.orange.shade300 : Colors.green.shade300;
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: Icon(Icons.circle, color: priorityColor, size: 12),
            title: Text(task.title, style: TextStyle(decoration: task.completed ? TextDecoration.lineThrough : null)),
            subtitle: Text('${task.category} | Score: $score'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Checkbox(
                  value: task.completed,
                  onChanged: (val) async {
                    task.completed = val ?? false;
                    await AppDatabase.updateTask(task);
                    _loadTasks();
                  },
                ),
                PopupMenuButton<String>(
                  onSelected: (value) async {
                    if (value == 'edit') {
                      _showTaskDialog(task: task);
                    } else if (value == 'delete') {
                      await AppDatabase.deleteTask(task.id);
                      _loadTasks();
                    } else if (value == 'postpone') {
                      task.postponed = true;
                      await AppDatabase.updateTask(task);
                      _loadTasks();
                    }
                  },
                  itemBuilder: (popupContext) => <PopupMenuEntry<String>>[
                    const PopupMenuItem<String>(value: 'edit', child: Text('Edit')),
                    const PopupMenuItem<String>(value: 'postpone', child: Text('Postpone')),
                    const PopupMenuItem<String>(value: 'delete', child: Text('Delete')),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatsTab() {
    final completedTasks = tasks.where((t) => t.completed).toList();
    final totalScore = tasks.fold<int>(0, (sum, t) => sum + ScoreCalculator.calculateTaskScore(t));
    final streakBonus = ScoreCalculator.calculateStreakBonus(completedTasks);
    final postponedCount = tasks.where((t) => t.postponed).length;
    Map<String, int> categoryCounts = {};
    for (var task in tasks) {
      categoryCounts[task.category] = (categoryCounts[task.category] ?? 0) + 1;
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text('Total Score', style: Theme.of(context).textTheme.titleMedium),
                  Text('${totalScore + streakBonus}', style: Theme.of(context).textTheme.displayMedium),
                  if (streakBonus > 0) Text('+ $streakBonus streak bonus', style: const TextStyle(color: Colors.green)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: StatCard(title: 'Total Tasks', value: tasks.length.toString())),
              const SizedBox(width: 8),
              Expanded(child: StatCard(title: 'Completed', value: completedTasks.length.toString())),
              const SizedBox(width: 8),
              Expanded(child: StatCard(title: 'Postponed', value: postponedCount.toString())),
            ],
          ),
          const SizedBox(height: 16),
          Text('Tasks by Category', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          SizedBox(
            height: 200,
            child: categoryCounts.isNotEmpty
                ? CustomPaint(
                    painter: PieChartPainter(
                        categoryCounts.values.toList(),
                        categoryCounts.keys.toList(),
                        Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    ),
                    child: Container(),
                  )
                : const Center(child: Text("No data for chart")),
          ),
        ],
      ),
    );
  }

  Widget _buildBackupTab() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ElevatedButton.icon(
            icon: const Icon(Icons.cloud_upload),
            label: const Text('Export Backup to JSON'),
            onPressed: () async {
              try {
                final file = await BackupService.exportDbToJson();
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Backup saved: ${file.path}')),
                );
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Export failed: $e')),
                );
              }
            },
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.cloud_download),
            label: const Text('Import Backup from JSON'),
            onPressed: () async {
              try {
                final dir = await getApplicationDocumentsDirectory();
                final file = File(p.join(dir.path, 'taskology_backup.json'));
                if (await file.exists()) {
                  await BackupService.importDbFromJson(file);
                  await _loadTasks();
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Backup restored successfully')),
                  );
                } else {
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Backup file not found in documents folder')),
                  );
                }
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Import failed: $e')),
                );
              }
            },
          ),
          const SizedBox(height: 24),
          const Text(
              "Backup file 'taskology_backup.json' is saved in your app's documents directory. To restore, place the file in the same location.",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  const StatCard({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Text(value, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text(title, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class PieChartPainter extends CustomPainter {
  final List<int> values;
  final List<String> labels;
  final Color labelColor;
  PieChartPainter(this.values, this.labels, this.labelColor);

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty) return;
    final total = values.fold<int>(0, (a, b) => a + b);
    if (total == 0) return;
    final paint = Paint()..style = PaintingStyle.fill;
    double startAngle = -pi / 2;
    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width / 2, size.height / 2) * 0.7;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final colors = [Colors.blue, Colors.red, Colors.green, Colors.orange, Colors.purple, Colors.teal, Colors.pink];
    for (int i = 0; i < values.length; i++) {
      final sweepAngle = (values[i] / total) * 2 * pi;
      paint.color = colors[i % colors.length];
      canvas.drawArc(rect, startAngle, sweepAngle, true, paint);
      final angle = startAngle + sweepAngle / 2;
      final labelRadius = radius * 1.3;
      final x = center.dx + labelRadius * cos(angle);
      final y = center.dy + labelRadius * sin(angle);
      final textPainter = TextPainter(
        text: TextSpan(
          text: '${labels[i]} (${(values[i] / total * 100).toStringAsFixed(0)}%)',
          style: TextStyle(color: labelColor, fontSize: 12, fontWeight: FontWeight.bold),
        ),
        textDirection: TextDirection.ltr,
      );
      textPainter.layout();
      textPainter.paint(canvas, Offset(x - textPainter.width / 2, y - textPainter.height / 2));
      startAngle += sweepAngle;
    }
  }

  @override
  bool shouldRepaint(covariant PieChartPainter oldDelegate) => oldDelegate.values != values || oldDelegate.labelColor != labelColor;
}