import 'package:flutter/material.dart';
import 'services/db_service.dart';
import 'ui/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // DB-i aç
  await DbService.getDatabase();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Taskology',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: const HomePage(), // Burada HomePage çağırılır
    );
  }
}
