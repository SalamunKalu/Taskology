import 'package:flutter/material.dart';
import 'services/db_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // DB-i aç
  final db = await DbService.getDatabase();

  // Test task əlavə et
  await db.insert('tasks', {
    'id': '1',
    'title': 'Test Task',
    'category': 'Work',
    'priority': 3,
    'totalMinutes': 60,
    'totalDays': 1,
    'weekdays': 'Mon,Tue,Wed',
    'createdAt': DateTime.now().toIso8601String(),
  });

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Taskology',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: const Scaffold(
        body: Center(
          child: Text('Taskology Ready!'),
        ),
      ),
    );
  }
}
