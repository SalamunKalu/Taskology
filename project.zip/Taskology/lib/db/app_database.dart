import 'package:sqflite_sqlcipher/sqflite.dart';
import 'package:path/path.dart';
import '../services/secure_storage_service.dart';
import '../utils/key_generator.dart';
import '../models/task.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> getDatabase() async {
    if (_db != null) return _db!;

    final storage = SecureStorageService();
    String? key = await storage.readDbKey();
    if (key == null) {
      key = generateDbKey();
      await storage.writeDbKey(key);
    }

    final path = join(await getDatabasesPath(), 'taskology.db');

    _db = await openDatabase(
      path,
      password: key,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE tasks(
            id TEXT PRIMARY KEY,
            title TEXT,
            category TEXT,
            priority INTEGER,
            totalMinutes INTEGER,
            totalDays INTEGER,
            weekdays TEXT,
            createdAt TEXT,
            completed INTEGER,
            postponed INTEGER
          )
        ''');
      },
    );

    return _db!;
  }

  // CRUD əməliyyatları
  static Future<void> insertTask(Task task) async {
    final db = await getDatabase();
    await db.insert('tasks', task.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<List<Task>> getTasks() async {
    final db = await getDatabase();
    final maps = await db.query('tasks');
    return maps.map((e) => Task.fromMap(e)).toList();
  }

  static Future<void> updateTask(Task task) async {
    final db = await getDatabase();
    await db.update('tasks', task.toMap(),
        where: 'id = ?', whereArgs: [task.id]);
  }

  static Future<void> deleteTask(String id) async {
    final db = await getDatabase();
    await db.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }
}
