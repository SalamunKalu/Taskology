import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  /// DB açarını secure storage-a yazır
  Future<void> writeDbKey(String key) async {
    await _storage.write(
      key: 'db_key',
      value: key,
      aOptions: const AndroidOptions(
        encryptedSharedPreferences: true,
      ),
    );
  }

  /// DB açarını oxuyur
  Future<String?> readDbKey() async {
    return await _storage.read(
      key: 'db_key',
      aOptions: const AndroidOptions(
        encryptedSharedPreferences: true,
      ),
    );
  }
}
