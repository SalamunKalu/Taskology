import 'package:sqflite_sqlcipher/sqflite.dart';
import 'package:path/path.dart';
import '../services/secure_storage_service.dart';
import '../utils/key_generator.dart';

class DbService {
  static Database? _db;

  /// DB açır və qaytarır
  static Future<Database> getDatabase() async {
    if (_db != null) return _db!;

    final storageService = SecureStorageService();

    // DB açarını secure storage-dan oxu
    String? dbKey = await storageService.readDbKey();

    // Əgər açar yoxdursa, yeni açar yarat və saxla
    if (dbKey == null) {
      dbKey = generateDbKey();
      await storageService.writeDbKey(dbKey);
    }

    final path = join(await getDatabasesPath(), 'taskology.db');

    _db = await openDatabase(
      path,
      password: dbKey,
      version: 1,
      onCreate: (db, version) async {
        // Task cədvəlini yarat
        await db.execute('''
          CREATE TABLE tasks (
            id TEXT PRIMARY KEY,
            title TEXT,
            category TEXT,
            priority INTEGER,
            totalMinutes INTEGER,
            totalDays INTEGER,
            weekdays TEXT,
            createdAt TEXT
          )
        ''');
      },
    );

    return _db!;
  }
}
