import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../db/app_database.dart';
import '../models/task.dart';

class BackupService {
  // DB export (.json)
  static Future<File> exportDbToJson() async {
    final db = await AppDatabase.getDatabase();
    final tasks = await db.query('tasks');

    final jsonStr = jsonEncode(tasks);

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/taskology_backup.json');
    return file.writeAsString(jsonStr);
  }

  // DB import (.json)
  static Future<void> importDbFromJson(File file) async {
    final content = await file.readAsString();
    final List<dynamic> data = jsonDecode(content);

    for (var map in data) {
      await AppDatabase.insertTask(Task.fromMap(map));
    }
  }
}
