class Task {
  final String id;
  final String title;
  final String category;
  final int priority; // 1=Aşağı, 2=Orta, 3=Yüksək
  final int totalMinutes;
  final int totalDays;
  final List<String> weekdays; // ["Mon","Tue",...]
  final DateTime createdAt;
  bool completed; // true/false
  bool postponed; // ertələnmiş

  Task({
    required this.id,
    required this.title,
    required this.category,
    required this.priority,
    required this.totalMinutes,
    required this.totalDays,
    required this.weekdays,
    required this.createdAt,
    this.completed = false,
    this.postponed = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'category': category,
      'priority': priority,
      'totalMinutes': totalMinutes,
      'totalDays': totalDays,
      'weekdays': weekdays.join(','),
      'createdAt': createdAt.toIso8601String(),
      'completed': completed ? 1 : 0,
      'postponed': postponed ? 1 : 0,
    };
  }

  factory Task.fromMap(Map<String, dynamic> map) {
    return Task(
      id: map['id'],
      title: map['title'],
      category: map['category'],
      priority: map['priority'],
      totalMinutes: map['totalMinutes'],
      totalDays: map['totalDays'],
      weekdays: map['weekdays'].toString().split(','),
      createdAt: DateTime.parse(map['createdAt']),
      completed: map['completed'] == 1,
      postponed: map['postponed'] == 1,
    );
  }
}
